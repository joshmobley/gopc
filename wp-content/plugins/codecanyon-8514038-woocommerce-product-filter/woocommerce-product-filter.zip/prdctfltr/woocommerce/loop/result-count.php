<?php

	global $prdctfltr_global;

	$prdctfltr_global['woo_template'] = 'result_count';

	include_once( 'product-filter.php' );

?>